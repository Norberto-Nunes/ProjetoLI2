#ifndef PROJETOLI2_INTERFACE_H
#define PROJETOLI2_INTERFACE_H

////funções
int jogar(ESTADO *e, COORDENADA c);
void mostrar_tabuleiro(ESTADO *e);
int interpretador(ESTADO *e);

#endif //PROJETOLI2_INTERFACE_H
